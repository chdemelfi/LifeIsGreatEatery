/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ItemPrices;

/**
 *
 * @author fethomas
 */
public class Parent_Desserts {
    
    public double Ice_Cream;
    public double Chocolate;
    public double Vanilla;
    public double StrawberryIce;
    public double Pistachio;
    public double Hot_Fudge;
    public double Whipped_Cream;
    public double Caramel;
    public double StrawberryTop;
    public double Oreo;
    public double Rainbow_Sprinkles;
    public double Chocolate_Sprinkles;
    public double Peanut_Butter;
    public double Walnuts;
    public double Reeses_Cup;
    public double M_Ms;
    public double No_Toppings;
    public double Brownie;
    public double Cheese_Cake;
    
    public double DessertCost;
    public double IceCream_Cost;
    
    /**
     * Accessor Method to return the total price of the desserts  chosen
     *      by the user
     * @return the total price of the desserts
     */
    public double GetAppetizerAmount(){
    
        DessertCost = Brownie + Cheese_Cake;
        
        IceCream_Cost = Ice_Cream + Chocolate + Vanilla + StrawberryIce + Pistachio + Hot_Fudge + Whipped_Cream 
            + Caramel + StrawberryTop + Oreo + Rainbow_Sprinkles +
            Chocolate_Sprinkles + Peanut_Butter + Walnuts + Reeses_Cup + M_Ms + No_Toppings;
        
        return(DessertCost + IceCream_Cost);
    
    }
    
}
