/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ItemPrices;

/**
 *
 * @author fethomas
 */
public class Child_Desserts extends Parent_Desserts {
    
    public double pIce_Cream = 0.00;
    public double pChocolate = 4.00;
    public double pVanilla = 4.00; 
    public double pStrawberryIce = 4.00;
    public double pPistachio = 4.00;
    public double pHot_Fudge = 0.50;
    public double pWhipped_Cream = 0.50;
    public double pCaramel = 0.50;
    public double pStrawberryTop = 0.50;
    public double pOreo = 0.50;
    public double pRainbow_Sprinkles = 0.50;
    public double pChocolate_Sprinkles = 0.50;
    public double pPeanut_Butter = 0.50;
    public double pWalnuts = 0.50;
    public double pReeses_Cup = 0.50;
    public double pM_Ms = 0.50;
    public double pNo_Toppings = 0.00;
    public double pBrownie = 2.50;
    public double pCheese_Cake = 3.50;
    
}
