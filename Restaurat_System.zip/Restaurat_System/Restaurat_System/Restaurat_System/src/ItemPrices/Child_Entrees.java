/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ItemPrices;

/**
 *
 * @author fethomas
 */
public class Child_Entrees extends Parent_Entrees {
    
    public double pPizza = 0.00;
    public double pSmall = 9.99;
    public double pMedium = 10.99;
    public double pLarge = 11.99;
    public double pPepperoni = 0.50;
    public double pPizza_Chicken = 0.50;
    public double pOlives = 0.00;
    public double pPineapple = 0.00;        
    public double pPizza_Broccoli = 0.00;
    public double pExtra_Cheese = 0.50;
    public double pPizza_Ham = 0.50;
    public double pPizza_Spinach = 0.00;        
    public double pPizza_Mushrooms = 0.00;
    public double pBeef = 0.50;
    public double pPizza_Pepper = 0.00;
    public double pNo_Toppings = 0.00;
            
    public double pPasta = 0.00;
    public double pSpaghetti = 11.99; 
    public double pPenne = 11.99;
    public double pRigatoni = 11.99;
    public double pFusili = 11.99;
    public double pAlfredo = 0.00;
    public double pTomato = 0.00;
    public double pOlive_Oil = 0.00;
    public double pNo_Sauce = 0.00;
    public double pMeatballs = 1.00;
    public double pPasta_Chicken = 1.00;
    public double pParmesan = 0.00;
    public double pPasta_Broccoli = 0.00; 
    public double pPasta_Spinach = 0.00;
    public double pPasta_Mushrooms = 0.00; 
    public double pEggplants = 0.00;
    public double pNo_Extras = 0.00;
    
    public double pSandwich = 0.00;
    public double pWheat = 0.00;
    public double pWhite = 0.00;
    public double pSixInch = 6.99;
    public double pTwelveInch = 10.99;
    public double pSandwich_Ham = 1.00;
    public double pTurkey = 1.00;
    public double pSalami = 1.00;
    public double pNo_Meat = 0.00;
    public double pToasted = 0.00;
    public double pMozz_Cheese = 0.00;
    public double pLettuce = 0.00;
    public double pSandwich_Tomato = 0.00;
    public double pCucumber = 0.00;
    public double pSandwich_Pepper = 0.00;
    public double pOnion = 0.00;
    public double pNo_SandExtras = 0.00;
  
}
