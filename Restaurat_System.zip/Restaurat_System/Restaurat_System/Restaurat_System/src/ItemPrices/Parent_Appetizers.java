/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ItemPrices;

/**
 *
 * @author fethomas
 */
public class Parent_Appetizers {
    
    public double Fries;
    public double Onion_Rings;
    public double Chicken_Tenders;
    public double Mozzarella_Sticks;
    
    public double Mushroom;
    public double Brocolli;
    public double Olives;
    public double Peppers;
    public double Spinach;
    public double Pineapple;
    
    public double AppetizerCost; 
    public double SideCost;
    
    public double GetAppetizerAmount(){
    
        AppetizerCost = Fries + Onion_Rings + Chicken_Tenders + Mozzarella_Sticks;
                        
        SideCost= Mushroom + Brocolli + Olives + Peppers + Spinach + Pineapple; 
        
        return(AppetizerCost + SideCost);
    
    }
}
