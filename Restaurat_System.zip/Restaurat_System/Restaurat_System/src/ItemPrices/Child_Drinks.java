/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ItemPrices;

/**
 *
 * @author fethomas
 */
public class Child_Drinks extends Parent_Drinks {
    
    public double pSoda = 2.00;
    public double pJuice = 1.50;
    public double pCoffee = 2.50;
    public double pWater = 0.00;
    
}
