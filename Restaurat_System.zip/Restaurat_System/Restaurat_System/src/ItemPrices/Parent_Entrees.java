/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ItemPrices;

/**
 *
 * @author fethomas
 */
public class Parent_Entrees {
    
    public double Pizza;
    public double Small;
    public double Medium;
    public double Large;
    public double Pepperoni;
    public double Pizza_Chicken;
    public double Olives;
    public double Pineapple;        
    public double Broccoli;
    public double Extra_Cheese;
    public double Pizza_Ham;
    public double Pizza_Spinach;        
    public double Mushrooms;
    public double Beef;
    public double Pizza_Pepper;
    public double No_Toppings;
            
    public double Pasta;
    public double Sphaghetti;
    public double Penne;
    public double Rigatoni;
    public double Fusili;
    public double Alfredo;
    public double Pasta_Tomato;
    public double Olive_Oil;
    public double No_Sauce;
    public double Meatballs;
    public double Pasta_Chicken;
    public double Parmesan;
    public double Pasta_Broccoli;
    public double Pasta_Spinach;
    public double Pasta_Mushrooms; 
    public double Eggplants;
    public double No_Extras;
    
    public double Sandwich;
    public double Wheat;
    public double White;
    public double SixInch;
    public double TwelveInch;
    public double Sandwich_Ham;
    public double Turkey;
    public double Salami;
    public double No_Meat;
    public double Toasted;
    public double Mozz_Cheese;
    public double Lettuce;
    public double Sandwich_Tomato;
    public double Cucumber;
    public double Sandwich_Pepper;
    public double Onion;
    public double No_SandExtras;
    
   
    public double NoodleCost;
    public double SauceCost;
    public double PastaExtrasCost;
    public double Pizza_SizeCost;
    public double Pizza_ToppCost; 
    public double BreadCost;
    public double Sandwich_SizeCost;
    public double Sandwich_MeatCost;
    public double Sandwich_ExtrasCost;
    
    
    public double GetFoodItemAmount(){
    
        
        NoodleCost = Pasta + Sphaghetti + Penne + Rigatoni + Fusili;
        
        SauceCost = Alfredo + Pasta_Tomato + Olive_Oil + No_Sauce;
        
        PastaExtrasCost = Meatballs + Pasta_Chicken + Parmesan + Pasta_Broccoli + Pasta_Spinach + Pasta_Mushrooms 
                     + Eggplants + No_Extras; 
        
        Pizza_SizeCost = Small + Medium + Large;
        
        Pizza_ToppCost =  Pizza_Chicken + Olives + Pineapple + Broccoli + Extra_Cheese 
                         + Pizza_Ham + Pizza_Spinach + Mushrooms + Beef + Pizza_Pepper + No_Toppings;
        
        BreadCost = Wheat + White;
        
        Sandwich_SizeCost =  SixInch + TwelveInch;
        
        Sandwich_MeatCost = Sandwich_Ham + Turkey + Salami + No_Meat ;
    
        Sandwich_ExtrasCost =  Toasted + Mozz_Cheese + Lettuce + Sandwich_Tomato + 
                               Cucumber + Sandwich_Pepper + Onion + No_SandExtras;
    
        
        return (NoodleCost + SauceCost + PastaExtrasCost + Pizza_SizeCost + 
                Pizza_ToppCost + BreadCost + Sandwich_SizeCost + Sandwich_MeatCost + 
                 Sandwich_ExtrasCost);
    
    }
    
}
