/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Desserts;

/**
 *
 * @author fethomas
 */
public class Child_Desserts extends Parent_Desserts {
    
    public double pIce_Cream = 4.00;
    public double pBrownie = 2.50;
    public double pCheese_Cake = 3.50;
}
