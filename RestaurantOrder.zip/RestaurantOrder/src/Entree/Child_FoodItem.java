/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entree;

/**
 *
 * @author fethomas
 */
public class Child_FoodItem extends Parent_FoodItem {
    
     public double pPizza = 9.99;
    public double pPasta = 11.99;
    public double pSandwich = 8.99;
    
}
