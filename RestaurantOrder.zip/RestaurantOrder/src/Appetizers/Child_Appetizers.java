/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Appetizers;

/**
 *
 * @author fethomas
 */
public class Child_Appetizers extends Parent_Appetizers {
    
    public double pFries = 2.50;
    public double pOnion_Rings = 3.50;
    public double pChicken_Tenders = 4.00;
    public double pMozzarella_Sticks = 4.50;
    public double pMushroom = 0.00;
    public double pBrocolli = 0.00;
    public double pOlives = 0.00;
    public double pPeppers = 0.00;
    public double pSpinach = 0.00;
    public double pPineapple = 0.00;
    
    
}
