/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Appetizers;

import javax.swing.JFrame; 
import javax.swing.JOptionPane;

/**
 *
 * @author fethomas
 */
public class Parent_Appetizers {
    
    public double Fries;
    public double Onion_Rings;
    public double Chicken_Tenders;
    public double Mozzarella_Sticks;
    
    public double Mushroom;
    public double Brocolli;
    public double Olives;
    public double Peppers;
    public double Spinach;
    public double Pineapple;
    
    public double AppetizerCost; 
    public double SideCost;
    
    public double GetAppetizerAmount(){
    
        AppetizerCost = Fries + Onion_Rings + Chicken_Tenders + Mozzarella_Sticks;
                        
        SideCost= Mushroom + Brocolli + Olives + Peppers + Spinach + Pineapple; 
        
        return(AppetizerCost + SideCost);
    
    }
    
    private JFrame CancelFrame;
    private JFrame CheckOutFrame;
    
    public void iCancelOrder(){
    
        CancelFrame = new JFrame ("Cancel");
        
        if(JOptionPane.showConfirmDialog(CancelFrame,"Confirm if you're sure you would like to cancel your order","Cancel Order",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION){
            System.exit(0);
        }
        
        
    
    }
    
      public void iCheckOutOrder(){
    
        CheckOutFrame = new JFrame ("Check Out");
        
        if(JOptionPane.showConfirmDialog(CheckOutFrame,"Confirm if you're sure you would like to check out","Check Out",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_NO_OPTION){
            System.exit(0);
        }
        
        
    
    }
    
}
